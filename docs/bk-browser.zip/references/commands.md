# bk 命令速查表

> 基于源码提取，所有命令均经过验证可用。

---

## 全局选项

每条命令都可以加：

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `-w, --ws <ID>` | string | — | 指定 workspace ID（或设 `BK_WS` 环境变量） |
| `--format <FMT>` | string | `text` | 输出格式：`text` \| `json` \| `tsv` |
| `-h` | flag | — | 简短帮助 |
| `--help` | flag | — | 完整帮助（含示例） |

```bash
# 指定 workspace
bk --ws abc123 goto https://example.com

# JSON 输出
bk --format json info
```

---

## 导航

### `goto <URL>`

导航到指定 URL，等待初始加载。

```bash
bk goto https://example.com
bk goto file:///tmp/test.html
```

### `back` / `forward`

浏览器历史前进/后退。

```bash
bk back
bk forward
```

### `reload`

刷新当前页面。

```bash
bk reload
```

### `url` / `title`

获取当前页面 URL 或标题。

```bash
bk url
bk title
```

---

## 页面状态

### `info`

获取可交互元素列表（带编号）+ 页面文本 + viewport 信息。**每次操作前必须先 info。**

| 参数 | 说明 |
|------|------|
| `--no-text` | 不返回页面文本（只要元素，更快） |
| `--screenshot` | 同时返回 viewport 截图（base64） |
| `--tree` | 按 DOM 祖先分组显示元素 |
| `--ax` | 附加 accessibility role/name |

```bash
bk info
bk info --no-text
bk info --tree
bk info --ax
bk info --screenshot --format json
```

> ⚠️ **不要截断 info 输出**，完整元素列表才能正确定位元素。
> ⚠️ **元素编号每次 DOM 更新后可能变化**，操作前重新 `bk info` 获取最新编号。

### `find <SELECTOR>`

按 CSS 选择器查询元素，返回结构化结果。

| 参数 | 说明 |
|------|------|
| `--attr <ATTRS>` | 返回指定属性（逗号分隔） |
| `--text` | 包含文本内容 |
| `--max <N>` | 最多返回 N 条（默认 50） |

```bash
bk find "a.nav-link" --attr href --text
bk find "tr" --max 20
bk find "img" --attr src,alt
```

### `search <PATTERN>`

页面全文搜索，返回匹配行 + 上下文（零 LLM cost）。

| 参数 | 说明 |
|------|------|
| `--regex` | 以正则表达式匹配 |
| `--scope <CSS>` | 限定搜索范围 |
| `--context <N>` | 匹配前后字符数（默认 40） |
| `--max <N>` | 最多返回 N 条（默认 50） |

```bash
bk search "错误信息"
bk search --regex "\d{4}-\d{2}-\d{2}" --max 5
bk search "price" --scope "div.product-list"
```

### `html`

获取页面 HTML。

```bash
bk html                        # 完整页面
bk html --selector "#main"     # 指定元素
```

### `console`

查看浏览器控制台日志缓冲（tab attach 后开始记录，最多 200 条）。

```bash
bk console
bk console --level error
bk console --limit 20
```

---

## 交互

> 所有需要 `<index>` 的命令，编号来自 `bk info` 输出中的 `[N]`。

### `click`

按编号、ref 或坐标点击元素（三选一必填）。

| 参数 | 说明 |
|------|------|
| `-i, --index <N>` | 按编号点击 |
| `-r, --ref <REF>` | 按稳定 ref 点击（DOM 变更后仍有效） |
| `--x <X> --y <Y>` | 按视口坐标点击（canvas/SVG 用） |

```bash
bk click -i 5
bk click --ref e42
bk click --x 300 --y 200
```

> ℹ️ click 返回结果包含 `new_tab` 字段，若点击触发了新标签页会提示 tid。

### `type`

向元素输入文本。

| 参数 | 说明 |
|------|------|
| `-i / -r` | 元素定位（必填） |
| `<TEXT>` | 要输入的文本（必填） |
| `--clear` | 输入前先清空原有内容 |
| `--autocomplete` | 输入后等待 400ms（combobox/搜索框自动补全） |

```bash
bk type -i 3 "hello world"
bk type -i 3 --clear "新内容"       # 替换原有内容
bk type -i 7 --autocomplete "上海"  # 等待下拉建议出现
```

> ⚠️ 默认是追加，**编辑已有内容必须加 `--clear`**。

### `fill`

批量填写多个字段，一次调用。

```bash
bk fill --set 3=John --set 4=Doe --set 5=john@example.com
bk fill --set ref:e42=hello --set ref:e55=world
```

格式：`<index>=<value>` 或 `ref:<backendNodeId>=<value>`

### `select`

选择 `<select>` 下拉框选项。先用 `bk options` 查看可选项。

```bash
bk options -i 4                    # 先查可选项
bk select -i 4 "上海"             # 再选择
bk select --ref e88 "option-value"
```

### `scroll`

| 参数 | 说明 |
|------|------|
| `[DIRECTION]` | `up` \| `down` \| `left` \| `right` \| `top` \| `bottom`（默认 down） |
| `--amount <PX>` | 滚动像素数（默认 500） |
| `-i / -r / -s` | 将指定元素滚入视口（与方向互斥） |

```bash
bk scroll                          # 向下 500px
bk scroll up --amount 1000
bk scroll bottom                   # 滚到页面底部
bk scroll -i 15                    # 将元素 15 滚入视口
bk scroll --selector "#section3"
```

### `hover`

悬停触发 CSS :hover、tooltip、下拉菜单。

```bash
bk hover -i 7
bk hover --ref e55
```

### `drag`

拖拽元素到目标（from/to 各三选一）。

```bash
bk drag --from-index 3 --to-index 8
bk drag --from-ref e10 --to-ref e20
bk drag --from-selector ".item" --to-selector ".dropzone"
```

### `focus`

聚焦元素（不点击）。

```bash
bk focus -i 3
```

### `upload`

向文件输入框上传文件，路径必须为绝对路径。

```bash
bk upload -i 5 "C:/Users/admin/Desktop/report.pdf"
bk upload --selector "input[type=file]" doc.pdf img.png
```

### `keys`

发送键盘按键。支持单键和修饰键组合。

```bash
bk keys "Enter"
bk keys "Tab"
bk keys "Escape"
bk keys "Control+a"     # 全选
bk keys "Shift+Enter"   # Shift+回车
bk keys "ArrowDown"
```

---

## 等待

### `wait`

等待页面条件（无参数时等待 networkidle）。各条件 OR 语义，任意一个满足即返回。

| 参数 | 说明 |
|------|------|
| `--selector <CSS>` | 等待元素可见 |
| `--text <STR>` | 等待文本出现 |
| `--text-gone <STR>` | 等待文本消失 |
| `--url <PATTERN>` | 等待 URL 包含字符串 |
| `--load-state <S>` | `load` \| `domcontentloaded` \| `networkidle` |
| `--fn <JS>` | 等待 JS 表达式返回 truthy |
| `--time <MS>` | 固定等待 N 毫秒 |
| `--timeout <MS>` | 超时时间（默认 30000ms） |

```bash
bk wait --selector ".modal"
bk wait --text "提交成功"
bk wait --text-gone "Loading..."
bk wait --load-state networkidle
bk wait --url "/dashboard"
bk wait --fn "document.querySelectorAll('li').length > 5"
bk wait --time 2000
bk wait --selector "#btn" --timeout 10000
```

---

## JavaScript

### `eval [EXPR]`

执行 JS 表达式。默认 async（支持 await）。

| 参数 | 说明 |
|------|------|
| `[EXPR]` | JS 表达式（内联） |
| `--sync` | 同步执行（不支持 await） |
| `--file <PATH>` | 从文件加载 JS |

```bash
bk eval "document.title"
bk eval "await fetch('/api').then(r => r.json())"
bk eval --sync "document.querySelectorAll('a').length"
bk eval --file script.js
bk eval "Array.from(document.querySelectorAll('.item')).map(e => e.textContent.trim())"
```

---

## 输出

### `shot`

截图。

| 参数 | 说明 |
|------|------|
| `-o, --output <FILE>` | 保存路径（不给则输出 base64） |
| `--full-page` | 整页截图 |
| `--selector <CSS>` | 截取指定元素 |
| `--labels` | 叠加元素编号标注（AI 定位用） |
| `[URL]` | one-shot 模式：导航后截图再退出 |

```bash
bk shot -o page.png
bk shot --full-page -o full.png
bk shot --selector "#chart" -o chart.png
bk shot --labels -o labeled.png          # 标注编号，方便 AI 识别
bk shot https://example.com -o out.png  # one-shot
```

> ⚠️ **整页截图 token 消耗极大**，优先用 `bk info` 文本方式。仅在必须视觉识别时用 `--labels`。

### `pdf`

生成 PDF。

```bash
bk pdf -o report.pdf
bk pdf --landscape -o wide.pdf
bk pdf https://example.com -o out.pdf   # one-shot
```

---

## 对话框

| 命令 | 说明 |
|------|------|
| `bk dialog list` | 查看待处理弹窗 |
| `bk dialog accept` | 确认弹窗（alert/confirm/prompt） |
| `bk dialog dismiss` | 取消弹窗 |
| `bk dialog policy <P>` | 设置自动策略：`ignore` \| `accept` \| `dismiss` \| `abort` |

```bash
bk dialog list
bk dialog accept
bk dialog policy accept    # 后续弹窗自动接受
```

> ⚠️ 页面弹出 alert/confirm 后，交互命令会超时。先处理弹窗再继续。

---

## 标签页

```bash
bk tab list                        # 列出所有标签页（含 tid、url、title）
bk tab new https://example.com     # 新建标签页
bk tab new                         # 新建空白标签页
bk tab switch <tid>                # 切换到指定标签页
bk tab attach "github.com"         # 将已有标签页加入 workspace（按 URL/title 匹配）
bk tab close <tid>                 # 关闭标签页
```

---

## Workspace

```bash
bk ws list                         # 列出所有 workspace（带 * 标记默认）
bk ws new                          # 新建隔离 workspace（独立 cookie）
bk ws new --attached               # 新建 attached workspace（共享登录态）
bk ws new --attached --pattern "github.com"  # 只 attach 匹配的标签页
bk ws use <wid>                    # 设为默认 workspace
bk ws default                      # 查看当前默认 workspace
bk ws close <wid>                  # 关闭（managed tab 关闭，unmanaged tab 只 detach）
bk ws close --all                  # 关闭所有
```

Workspace ID 为 16 位 hex，支持前缀匹配（如 `a3f2` 代替完整 ID）。

---

## 浏览器连接

```bash
bk browser discover                # 通过 DevToolsActivePort 自动发现 Chrome
bk browser discover --path /custom/DevToolsActivePort
bk browser connect localhost:9222  # 按 host:port 连接
bk browser connect "ws://localhost:9222/devtools/browser/<guid>"  # 直接 ws URL
bk browser list                    # 列出已连接的浏览器
bk browser disconnect <host>       # 断开连接
```

---

## Cookie / Storage

```bash
bk storage cookies get             # 获取所有 cookie
bk storage cookies get --url https://example.com  # 按 URL 过滤
bk storage cookies set '[{"name":"k","value":"v","domain":"example.com"}]'
bk storage cookies clear
bk storage local get <key>         # localStorage get
bk storage local set <key> <val>   # localStorage set
bk storage export                  # 导出完整 storage 状态（JSON）
bk storage import state.json       # 导入 storage 状态
```

---

## Daemon

```bash
bk daemon status                   # 查看 daemon 状态（pid、端口、uptime、workspace 列表）
bk daemon stop                     # 优雅停止 daemon
bk status                          # daemon + 浏览器 + workspace 概览
```

daemon 在第一次运行任何命令时自动启动，无需手动 `bk daemon start`。

---

## 调试

```bash
bk debug monitor                   # 实时流式输出网络事件
bk debug har https://example.com   # 导航并记录 HAR
bk debug block "*.ads.com/*"       # 拦截 URL 模式
bk debug unblock                   # 取消拦截
bk debug cdp Page.captureScreenshot '{"format":"png"}'  # 发送原始 CDP 命令
bk debug events --filter "Network" # 流式输出 CDP 事件
```
