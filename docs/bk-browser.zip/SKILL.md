---
name: bk-browser
display_name: bk 浏览器自动化
description: 用 bk CLI 控制本地 Chrome 做浏览器自动化。连接用户已运行的浏览器（保留登录态/cookie），或启动隔离的无头浏览器，执行导航、交互、截图、数据抽取等操作。
allowed-tools: Bash(bk *) Bash(bk.exe *) Bash(tasklist*) Bash(pgrep*) Bash(test -f*)
metadata:
  code: bk-browser
  skillCode: bk-browser
version: 0.1.0
tags: [浏览器自动化, 网页交互, RPA, AI-Agent, 数据抽取]
---

# 用 bk CLI 做浏览器自动化

`bk` 通过后台 daemon 维持持久 CDP 连接，每次命令约 30ms 延迟。

> **必须使用用户自己的浏览器（接管模式）。** bk 连接用户已运行的 Chrome，在用户可见窗口操作，复用已登录的 cookie 和会话，无需重新登录。**禁止启动隔离的无头浏览器。**

---

## 前置：确认 bk 可用并连接浏览器

### 第一步：确认 bk 已安装

```bash
bk daemon status
```

- **成功（返回 daemon 状态）** → 跳到第二步
- **失败/命令未找到** → 提示用户从 https://github.com/yie1d/browserkit/releases 下载对应平台的压缩包，解压后将 `bk`（Windows 为 `bk.exe`）放到 PATH 目录，再重试

### 第二步：接管用户的 Chrome（优先）

```bash
bk browser discover
```

- **成功** → 创建 attached workspace，共享用户登录态：
  ```bash
  bk ws new --attached
  ```
  直接进入工作流。

- **失败** → 按下方排查流程处理。

---

**discover 失败排查流程：**

**① 检查 Chrome 是否在运行**

- Windows：`tasklist | findstr chrome`
- macOS/Linux：`pgrep -l -i chrome`

**Chrome 在运行 → 检查远程调试是否已开启**

检查 `DevToolsActivePort` 文件是否存在：

| 系统 | 路径 |
|---|---|
| Windows | `%LOCALAPPDATA%\Google\Chrome\User Data\DevToolsActivePort` |
| macOS | `~/Library/Application Support/Google/Chrome/DevToolsActivePort` |
| Linux | `~/.config/google-chrome/DevToolsActivePort` |

- **文件不存在** → 引导用户开启远程调试：
  > "需要在 Chrome 中开启远程调试，只需设置一次，重启后保留。请在 Chrome 地址栏打开 `chrome://inspect/#remote-debugging`，勾选"开启远程调试"，完成后告诉我。"
  用户开启后再执行 `bk browser discover`。

- **文件存在但 discover 仍失败** → 直接用文件内容连接：
  ```bash
  # 文件第一行=端口，第二行=ws路径
  bk browser connect "ws://127.0.0.1:<端口><ws路径>"
  bk ws new --attached
  ```

**Chrome 没有进程 → 检查 Edge 是否在运行**

- Windows：`tasklist | findstr msedge`
- macOS/Linux：`pgrep -l -i "microsoft edge"`

**Edge 在运行 → 检查 Edge 的 DevToolsActivePort**

| 系统 | 路径 |
|---|---|
| Windows | `%LOCALAPPDATA%\Microsoft\Edge\User Data\DevToolsActivePort` |
| macOS | `~/Library/Application Support/Microsoft Edge/DevToolsActivePort` |
| Linux | `~/.config/microsoft-edge/DevToolsActivePort` |

- 文件存在 → 读取端口和 ws 路径，用 `--host` 连接：
  ```bash
  bk browser connect "ws://127.0.0.1:<端口><ws路径>"
  bk ws new --attached
  ```
- 文件不存在 → 引导用户开启 Edge 远程调试：
  > "需要在 Edge 中开启远程调试。请在 Edge 地址栏打开 `edge://inspect/#remote-debugging`，勾选"开启远程调试"，完成后告诉我。"

**Chrome 和 Edge 都没有进程 →**
> "未检测到 Chrome 或 Edge。请先打开 Chrome，完成后告诉我继续。"

---

**接管模式连接成功后**，若触发授权弹窗（首次连接）：

1. 执行连接命令 → 弹出授权框，命令可能超时退出（正常现象）
2. 告知用户：
   > "浏览器弹出了授权对话框，请点击"允许"，完成后告诉我。"
3. 用户点允许后再执行一次连接命令
4. 授权完成后后续会话不再弹窗


---

## 核心工作流

1. **连接**：`bk browser discover` → `bk ws new --attached`（接管用户 Chrome）
2. **确认 tab**：`bk tab list` 查看所有 tab → `bk tab switch <tid>` 切到用户正在看的页面（**必须做，否则操作在后台 tab 执行，用户看不到**）
3. **导航**：`bk goto <url>`
4. **观察**：`bk info` —— 返回带编号的可交互元素 + 页面文本（**每次操作前必须先 info**）
5. **交互**：用编号操作（`bk click -i 5`、`bk type -i 3 "文本"`）
6. **验证**：再次 `bk info` 确认结果
7. **重复**：daemon 在命令之间保持连接

操作失败时先 `bk daemon stop` 清掉 daemon，再重新 `bk browser discover` + `bk ws new --attached`。

---

## 常用命令速查

```bash
# 导航
bk goto <url>          bk back          bk forward          bk reload

# 页面状态（操作前必须先执行）
bk info                              # 元素列表 + 页面文本 + viewport
bk info --no-text                    # 只要元素列表（更快）
bk info --tree                       # 按 DOM 层级分组
bk info --ax                         # 附加 accessibility 语义
bk shot --labels -o labeled.png      # 截图 + 标注编号（视觉定位用）

# 交互（<N> = info 返回的编号）
bk click -i <N>                      bk click --x <X> --y <Y>
bk type -i <N> "text"                bk type -i <N> --clear "text"
bk fill --set <N>=<val> --set <M>=<val>
bk options -i <N>                    bk select -i <N> "选项文本"
bk scroll [up|down|top|bottom]       bk scroll -i <N>
bk hover -i <N>                      bk keys "Enter"

# 等待
bk wait --selector ".cls"            bk wait --text "成功"
bk wait --text-gone "Loading"        bk wait --load-state networkidle
bk wait --url "/dashboard"           bk wait --time 2000

# 数据抽取
bk eval "document.title"             bk eval "await fetch('/api').then(r=>r.json())"
bk html --selector "#main"           bk search "关键词"
bk find "a.nav-link" --text

# 对话框
bk dialog accept                     bk dialog policy accept

# 标签页
bk tab list    bk tab new <url>    bk tab switch <tid>    bk tab close <tid>
```

完整参数说明见 [`references/commands.md`](references/commands.md)。

---

## 元素定位：三种方式

| 方式 | 命令示例 | 适用场景 |
|------|---------|---------|
| **index（编号）** | `bk click -i 5` | 最常用，从 `bk info` 输出获取 |
| **ref（稳定引用）** | `bk click --ref e42` | DOM 动态变化时用，从 `bk info --format json` 获取 |
| **坐标** | `bk click --x 300 --y 200` | canvas、SVG、无法定位的元素 |

**ref vs index**：index 在每次 `info` 后可能变化（DOM 增减元素）；ref（backendNodeId）在节点未被移除时始终稳定，适合多步操作中间有 DOM 变化的场景。

---

## 多 Workspace 工作流

```bash
# 两个独立会话并行
bk ws new --label "session-a"    # 创建 workspace A
bk ws new --label "session-b"    # 创建 workspace B
bk ws list                       # 查看两个 workspace 的 ID

bk --ws <wid-a> goto https://site-a.com
bk --ws <wid-b> goto https://site-b.com

bk --ws <wid-a> info             # 操作 A
bk --ws <wid-b> info             # 操作 B
```

或用环境变量：
```bash
export BK_WS=<wid-a>
bk goto https://site-a.com
bk info
```

---

## 注意事项（重要）

1. **确认操作的是用户可见的 tab**：`bk ws new --attached` 后务必用 `bk tab list` 确认当前活动 tab，再用 `bk tab switch <tid>` 切到用户正在看的那个页面。否则 bk 可能在后台 tab 操作，用户看不到任何动作。
   ```bash
   bk tab list               # 查看所有 tab 和对应 tid
   bk tab switch <tid>       # 切到用户可见的 tab
   bk url                    # 确认当前 tab URL 正确
   ```

2. **永远先 `bk info`**：每次操作前先拿到元素编号，不要猜编号
2. **不要截断 info 输出**：完整元素列表才能正确定位；截断会导致操作失败率大幅上升
3. **`bk type` 默认追加**：编辑已有内容用 `--clear`，否则会在原值后追加
4. **select 先查选项**：`bk options -i <N>` 先看可选项，再 `bk select -i <N> "选项文本"`
5. **元素编号会变**：DOM 更新后编号可能漂移，每次操作前重新 `bk info` 获取最新编号；或改用 `--ref` 做稳定寻址
6. **接管模式不关 Chrome**：`bk ws close` 只 detach session，用户的 Chrome 窗口和标签页不受影响
7. **screenshot 消耗 token**：整页截图 token 消耗极大，优先用 `bk info` 文本方式；仅在必须视觉识别时才用 `bk shot --labels`
8. **弹窗会阻塞交互**：页面弹出 alert/confirm 后点击命令会超时，先 `bk dialog accept` 或 `bk dialog policy accept` 处理
9. **daemon 自动启动**：第一次运行任何命令会自动启动 daemon，无需手动 `bk daemon start`

---

## 常用操作示例

### 登录表单

```bash
bk goto https://example.com/login
bk info
# 假设 email=index 3, password=index 4, 登录按钮=index 5
bk type -i 3 --clear "user@example.com"
bk type -i 4 --clear "mypassword"
bk click -i 5
bk wait --url "/dashboard"       # 等待跳转到首页
bk info                          # 确认登录成功
```

### 处理下拉框

```bash
bk info
bk options -i 7                  # 先查看可选项
# 输出: 1. 北京  2. 上海  3. 广州
bk select -i 7 "上海"
bk info                          # 确认选中
```

### 等待动态内容加载

```bash
bk goto https://example.com/data
bk wait --selector "#data-table" --timeout 10000
bk html --selector "#data-table"
```

### 抓取列表数据

```bash
bk goto https://example.com/list
bk wait --load-state networkidle
bk eval "Array.from(document.querySelectorAll('.item-title')).map(e => e.textContent.trim())"
```

### 多标签页操作

```bash
bk tab new https://site-a.com
bk tab new https://site-b.com
bk tab list
bk tab switch <tid-a>
bk info
bk tab switch <tid-b>
bk info
```

### 接管已登录的 Chrome

```bash
bk browser discover              # 发现已运行的 Chrome
bk ws new --attached             # 共享登录态，不新建 context
bk info                          # 查看当前页面元素
bk goto https://app.example.com/dashboard
```

---

## 排错

| 问题 | 解决方法 |
|------|---------|
| `browser not found` | `bk browser discover` 或 `bk browser connect localhost:<port>` |
| `workspace not found` | `bk ws list` 查看，`bk ws use <wid>` 切换 |
| 找不到元素 | `bk scroll bottom` 后再 `bk info`，或 `bk search "关键词"` 定位 |
| 点击超时（弹窗阻塞） | `bk dialog accept` 或 `bk dialog policy accept` 后重试 |
| daemon 异常 | `bk daemon stop`，再重新 `bk browser discover` + `bk ws new --attached` |
| 编号对不上 | 重新 `bk info` 获取最新编号，DOM 可能已更新 |

## 清理

```bash
bk ws close <wid>    # 关闭指定 workspace（managed tab 会关闭，用户 tab 只 detach）
bk daemon stop       # 停止 daemon（释放所有资源）
```

---

## 参考

- 完整命令参数速查：[`references/commands.md`](references/commands.md)
- bk 项目主页：https://github.com/yie1d/browserkit
